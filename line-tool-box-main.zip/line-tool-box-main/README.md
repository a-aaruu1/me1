LINEで使えるWebツール集
自己責任です。　
旧: https://line.naver.jp/R/app/2000174578-VrlmbbrB  

新: https://line.naver.jp/R/app/2001110580-p8w3dBZq   

直: https://line-tool.ame-x.net

自作検索サイト: https://line-tool.ame-x.net/search

- 予定
```yaml
- /token : token開示
- /hijack/{id} : token短縮 => 乗っ取り
- /flex/{flex} : flex短縮 => flex送信
- /send/{text} : text短縮 => text送信
- /trp/{anyone} : trap (ユニコード地雷等)
```
アイデア募集中

☑ LINE SendAPI  
☑ 高度なツール群  
☑ Tokenを利用した LINE初のツール

### 新
Angular OR NextJS

```
npm run dev
```
# Angular
```
npm i
npm run dev:ssr
```

### 旧
## 開発サーバー起動
```
npm run start
```

## ビルド
```
npm run build
```

node_modules
```
npm i
```
