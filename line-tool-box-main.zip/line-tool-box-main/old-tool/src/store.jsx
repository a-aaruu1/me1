import { createContext } from 'react';

export const WithDevCtx = createContext();
