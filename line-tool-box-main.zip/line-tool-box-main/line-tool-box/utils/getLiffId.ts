export function getLiffId(): string {
  // const query = new URLSearchParams(window.location.search).get("liffId");
  const liffId = "2004693304-kl5BjM6X"; // ブラウザ動作含め
  return liffId;
}
